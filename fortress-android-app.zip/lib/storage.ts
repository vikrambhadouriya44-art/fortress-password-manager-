// FORTRESS Local Storage Manager
// Handles secure storage of encrypted data

import { encrypt, decrypt, hashPassword } from "./crypto"

export interface Note {
  id: string
  title: string
  content: string
  createdAt: string
  updatedAt: string
  isLocked: boolean
}

export interface Password {
  id: string
  name: string
  username: string
  password: string
  protectionLevel: "easy" | "moderate" | "hard"
  createdAt: string
  updatedAt: string
}

export interface VaultData {
  notes: Note[]
  passwords: Password[]
  masterPasswordHash: string
  createdAt: string
}

const STORAGE_KEY = "fortress_vault"

// Initialize vault with master password
export async function initializeVault(masterPassword: string): Promise<void> {
  const hash = await hashPassword(masterPassword)
  const vault: VaultData = {
    notes: [],
    passwords: [],
    masterPasswordHash: hash,
    createdAt: new Date().toISOString(),
  }
  const encrypted = await encrypt(JSON.stringify(vault), masterPassword)
  localStorage.setItem(STORAGE_KEY, encrypted)
}

// Check if vault exists
export function vaultExists(): boolean {
  return localStorage.getItem(STORAGE_KEY) !== null
}

// Verify master password
export async function verifyMasterPassword(password: string): Promise<boolean> {
  const encrypted = localStorage.getItem(STORAGE_KEY)
  if (!encrypted) return false

  try {
    const decrypted = await decrypt(encrypted, password)
    const vault: VaultData = JSON.parse(decrypted)
    const hash = await hashPassword(password)
    return vault.masterPasswordHash === hash
  } catch {
    return false
  }
}

// Load vault data
export async function loadVault(masterPassword: string): Promise<VaultData | null> {
  const encrypted = localStorage.getItem(STORAGE_KEY)
  if (!encrypted) return null

  try {
    const decrypted = await decrypt(encrypted, masterPassword)
    return JSON.parse(decrypted)
  } catch {
    return null
  }
}

// Save vault data
export async function saveVault(vault: VaultData, masterPassword: string): Promise<void> {
  const encrypted = await encrypt(JSON.stringify(vault), masterPassword)
  localStorage.setItem(STORAGE_KEY, encrypted)
}

// Add note
export async function addNote(
  note: Omit<Note, "id" | "createdAt" | "updatedAt">,
  masterPassword: string,
): Promise<Note> {
  const vault = await loadVault(masterPassword)
  if (!vault) throw new Error("Vault not found")

  const newNote: Note = {
    ...note,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  vault.notes.push(newNote)
  await saveVault(vault, masterPassword)
  return newNote
}

// Update note
export async function updateNote(id: string, updates: Partial<Note>, masterPassword: string): Promise<Note | null> {
  const vault = await loadVault(masterPassword)
  if (!vault) throw new Error("Vault not found")

  const index = vault.notes.findIndex((n) => n.id === id)
  if (index === -1) return null

  vault.notes[index] = {
    ...vault.notes[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  }

  await saveVault(vault, masterPassword)
  return vault.notes[index]
}

// Delete note
export async function deleteNote(id: string, masterPassword: string): Promise<boolean> {
  const vault = await loadVault(masterPassword)
  if (!vault) throw new Error("Vault not found")

  const index = vault.notes.findIndex((n) => n.id === id)
  if (index === -1) return false

  vault.notes.splice(index, 1)
  await saveVault(vault, masterPassword)
  return true
}

// Add password
export async function addPassword(
  password: Omit<Password, "id" | "createdAt" | "updatedAt">,
  masterPassword: string,
): Promise<Password> {
  const vault = await loadVault(masterPassword)
  if (!vault) throw new Error("Vault not found")

  // Encrypt the password based on protection level
  const encryptedPassword = await encrypt(password.password, masterPassword)

  const newPassword: Password = {
    ...password,
    password: encryptedPassword,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  vault.passwords.push(newPassword)
  await saveVault(vault, masterPassword)
  return newPassword
}

// Update password
export async function updatePassword(
  id: string,
  updates: Partial<Password>,
  masterPassword: string,
): Promise<Password | null> {
  const vault = await loadVault(masterPassword)
  if (!vault) throw new Error("Vault not found")

  const index = vault.passwords.findIndex((p) => p.id === id)
  if (index === -1) return null

  // If password field is being updated, encrypt it
  if (updates.password) {
    updates.password = await encrypt(updates.password, masterPassword)
  }

  vault.passwords[index] = {
    ...vault.passwords[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  }

  await saveVault(vault, masterPassword)
  return vault.passwords[index]
}

// Delete password
export async function deletePassword(id: string, masterPassword: string): Promise<boolean> {
  const vault = await loadVault(masterPassword)
  if (!vault) throw new Error("Vault not found")

  const index = vault.passwords.findIndex((p) => p.id === id)
  if (index === -1) return false

  vault.passwords.splice(index, 1)
  await saveVault(vault, masterPassword)
  return true
}

// Get decrypted password
export async function getDecryptedPassword(encryptedPassword: string, masterPassword: string): Promise<string> {
  return decrypt(encryptedPassword, masterPassword)
}

// Change master password
export async function changeMasterPassword(oldPassword: string, newPassword: string): Promise<boolean> {
  const vault = await loadVault(oldPassword)
  if (!vault) return false

  // Re-encrypt all passwords with new master password
  for (const pwd of vault.passwords) {
    const decrypted = await decrypt(pwd.password, oldPassword)
    pwd.password = await encrypt(decrypted, newPassword)
  }

  // Update hash
  vault.masterPasswordHash = await hashPassword(newPassword)

  // Save with new password
  await saveVault(vault, newPassword)
  return true
}

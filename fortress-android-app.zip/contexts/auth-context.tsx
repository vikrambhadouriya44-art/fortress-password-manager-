"use client"

import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react"
import { vaultExists, verifyMasterPassword, initializeVault, loadVault, type VaultData } from "@/lib/storage"

interface AuthContextType {
  isAuthenticated: boolean
  isFirstTime: boolean
  isLoading: boolean
  masterPassword: string | null
  vault: VaultData | null
  login: (password: string) => Promise<boolean>
  setup: (password: string) => Promise<boolean>
  logout: () => void
  refreshVault: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isFirstTime, setIsFirstTime] = useState(true)
  const [isLoading, setIsLoading] = useState(true)
  const [masterPassword, setMasterPassword] = useState<string | null>(null)
  const [vault, setVault] = useState<VaultData | null>(null)

  useEffect(() => {
    setIsFirstTime(!vaultExists())
    setIsLoading(false)
  }, [])

  const login = useCallback(async (password: string): Promise<boolean> => {
    const isValid = await verifyMasterPassword(password)
    if (isValid) {
      setMasterPassword(password)
      setIsAuthenticated(true)
      const vaultData = await loadVault(password)
      setVault(vaultData)
    }
    return isValid
  }, [])

  const setup = useCallback(async (password: string): Promise<boolean> => {
    try {
      await initializeVault(password)
      setMasterPassword(password)
      setIsAuthenticated(true)
      setIsFirstTime(false)
      const vaultData = await loadVault(password)
      setVault(vaultData)
      return true
    } catch {
      return false
    }
  }, [])

  const logout = useCallback(() => {
    setIsAuthenticated(false)
    setMasterPassword(null)
    setVault(null)
  }, [])

  const refreshVault = useCallback(async () => {
    if (masterPassword) {
      const vaultData = await loadVault(masterPassword)
      setVault(vaultData)
    }
  }, [masterPassword])

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isFirstTime,
        isLoading,
        masterPassword,
        vault,
        login,
        setup,
        logout,
        refreshVault,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

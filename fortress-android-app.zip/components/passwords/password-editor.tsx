"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { Password } from "@/lib/storage"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { X, Save, Eye, EyeOff, RefreshCw, Shield, ShieldCheck, ShieldAlert } from "lucide-react"

interface PasswordEditorProps {
  password?: Password | null
  existingDecryptedPassword?: string
  onSave: (data: {
    name: string
    username: string
    password: string
    protectionLevel: "easy" | "moderate" | "hard"
  }) => void
  onCancel: () => void
}

export function PasswordEditor({ password, existingDecryptedPassword, onSave, onCancel }: PasswordEditorProps) {
  const [name, setName] = useState("")
  const [username, setUsername] = useState("")
  const [passwordValue, setPasswordValue] = useState("")
  const [protectionLevel, setProtectionLevel] = useState<"easy" | "moderate" | "hard">("moderate")
  const [showPassword, setShowPassword] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    if (password) {
      setName(password.name)
      setUsername(password.username)
      setPasswordValue(existingDecryptedPassword || "")
      setProtectionLevel(password.protectionLevel)
    } else {
      setName("")
      setUsername("")
      setPasswordValue("")
      setProtectionLevel("moderate")
    }
  }, [password, existingDecryptedPassword])

  const generatePassword = () => {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
    let result = ""
    for (let i = 0; i < 16; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setPasswordValue(result)
    setShowPassword(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !username.trim() || !passwordValue.trim()) return

    setIsSaving(true)
    await onSave({
      name: name.trim(),
      username: username.trim(),
      password: passwordValue.trim(),
      protectionLevel,
    })
    setIsSaving(false)
  }

  const protectionLevels: { level: "easy" | "moderate" | "hard"; icon: React.ElementType; description: string }[] = [
    { level: "easy", icon: Shield, description: "Basic encryption" },
    { level: "moderate", icon: ShieldCheck, description: "Strong encryption" },
    { level: "hard", icon: ShieldAlert, description: "Re-auth required" },
  ]

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{password ? "Edit Password" : "New Password"}</CardTitle>
          <Button variant="ghost" size="icon" onClick={onCancel} className="text-muted-foreground">
            <X className="h-5 w-5" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">App / Website Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Gmail, Netflix"
              className="bg-secondary border-border"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Username / Email</Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="your@email.com"
              className="bg-secondary border-border"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={passwordValue}
                  onChange={(e) => setPasswordValue(e.target.value)}
                  placeholder="Enter password"
                  className="bg-secondary border-border pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <Button type="button" variant="outline" size="icon" onClick={generatePassword} className="bg-transparent">
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Protection Level</Label>
            <div className="grid grid-cols-3 gap-2">
              {protectionLevels.map(({ level, icon: Icon, description }) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setProtectionLevel(level)}
                  className={`p-3 rounded-lg border text-center transition-all ${
                    protectionLevel === level
                      ? "border-primary bg-primary/10"
                      : "border-border bg-secondary hover:bg-secondary/80"
                  }`}
                >
                  <Icon
                    className={`h-5 w-5 mx-auto mb-1 ${protectionLevel === level ? "text-primary" : "text-muted-foreground"}`}
                  />
                  <div className="text-xs font-medium text-foreground capitalize">{level}</div>
                  <div className="text-[10px] text-muted-foreground">{description}</div>
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {protectionLevel === "easy" && "Uses 50,000 PBKDF2 iterations for key derivation."}
              {protectionLevel === "moderate" && "Uses 100,000 PBKDF2 iterations for stronger protection."}
              {protectionLevel === "hard" && "Uses 200,000 PBKDF2 iterations and requires re-authentication to view."}
            </p>
          </div>

          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" className="flex-1 bg-transparent" onClick={onCancel}>
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={isSaving || !name.trim() || !username.trim() || !passwordValue.trim()}
            >
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? "Saving..." : "Save"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

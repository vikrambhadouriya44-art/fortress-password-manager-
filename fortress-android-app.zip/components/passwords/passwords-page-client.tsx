"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { addPassword, updatePassword, deletePassword, getDecryptedPassword, type Password } from "@/lib/storage"
import { PasswordList } from "@/components/passwords/password-list"
import { PasswordEditor } from "@/components/passwords/password-editor"
import { ReAuthModal } from "@/components/passwords/re-auth-modal"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Plus, Key, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export function PasswordsPageClient() {
  const router = useRouter()
  const { isAuthenticated, masterPassword, vault, refreshVault } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [editingPassword, setEditingPassword] = useState<Password | null>(null)
  const [decryptedPassword, setDecryptedPassword] = useState<string>("")
  const [searchQuery, setSearchQuery] = useState("")
  const [showReAuth, setShowReAuth] = useState(false)
  const [pendingCallback, setPendingCallback] = useState<(() => void) | null>(null)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/")
    }
  }, [isAuthenticated, router])

  const handleRequireAuth = useCallback((callback: () => void) => {
    setPendingCallback(() => callback)
    setShowReAuth(true)
  }, [])

  const handleReAuthSuccess = useCallback(() => {
    setShowReAuth(false)
    if (pendingCallback) {
      pendingCallback()
      setPendingCallback(null)
    }
  }, [pendingCallback])

  if (!isAuthenticated || !masterPassword) {
    return null
  }

  const passwords = vault?.passwords || []
  const filteredPasswords = passwords.filter(
    (pwd) =>
      pwd.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pwd.username.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleSave = async (data: {
    name: string
    username: string
    password: string
    protectionLevel: "easy" | "moderate" | "hard"
  }) => {
    if (editingPassword) {
      await updatePassword(editingPassword.id, data, masterPassword)
    } else {
      await addPassword(data, masterPassword)
    }
    await refreshVault()
    setIsEditing(false)
    setEditingPassword(null)
    setDecryptedPassword("")
  }

  const handleEdit = async (pwd: Password) => {
    try {
      const decrypted = await getDecryptedPassword(pwd.password, masterPassword)
      setDecryptedPassword(decrypted)
      setEditingPassword(pwd)
      setIsEditing(true)
    } catch (e) {
      console.error("Failed to decrypt password for editing", e)
    }
  }

  const handleDelete = async (id: string) => {
    await deletePassword(id, masterPassword)
    await refreshVault()
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center gap-3 px-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="text-muted-foreground">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <Key className="h-5 w-5 text-primary" />
            <span className="font-semibold text-foreground">Password Manager</span>
          </div>
          <div className="ml-auto">
            {!isEditing && (
              <Button
                size="sm"
                onClick={() => {
                  setEditingPassword(null)
                  setDecryptedPassword("")
                  setIsEditing(true)
                }}
              >
                <Plus className="h-4 w-4 mr-1" />
                New
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-6 space-y-4">
        {isEditing ? (
          <PasswordEditor
            password={editingPassword}
            existingDecryptedPassword={decryptedPassword}
            onSave={handleSave}
            onCancel={() => {
              setIsEditing(false)
              setEditingPassword(null)
              setDecryptedPassword("")
            }}
          />
        ) : (
          <>
            {/* Search */}
            {passwords.length > 0 && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search passwords..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-card border-border"
                />
              </div>
            )}

            {/* Password List */}
            <PasswordList
              passwords={filteredPasswords}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onRequireAuth={handleRequireAuth}
            />
          </>
        )}
      </main>

      {/* Re-authentication Modal */}
      <ReAuthModal
        isOpen={showReAuth}
        onSuccess={handleReAuthSuccess}
        onCancel={() => {
          setShowReAuth(false)
          setPendingCallback(null)
        }}
      />
    </div>
  )
}

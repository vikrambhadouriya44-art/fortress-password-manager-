"use client"

import { useState } from "react"
import type { Password } from "@/lib/storage"
import { getDecryptedPassword } from "@/lib/storage"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ProtectionBadge } from "@/components/protection-badge"
import { Key, Copy, Eye, EyeOff, Trash2, Edit, Check, Lock } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

interface PasswordListProps {
  passwords: Password[]
  onEdit: (password: Password) => void
  onDelete: (id: string) => void
  onRequireAuth: (callback: () => void) => void
}

export function PasswordList({ passwords, onEdit, onDelete, onRequireAuth }: PasswordListProps) {
  const { masterPassword } = useAuth()
  const [visiblePasswords, setVisiblePasswords] = useState<Map<string, string>>(new Map())
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null)
  const [loadingId, setLoadingId] = useState<string | null>(null)

  const toggleVisibility = async (pwd: Password) => {
    if (!masterPassword) return

    if (visiblePasswords.has(pwd.id)) {
      setVisiblePasswords((prev) => {
        const next = new Map(prev)
        next.delete(pwd.id)
        return next
      })
    } else {
      // For hard protection level, require re-authentication
      if (pwd.protectionLevel === "hard") {
        onRequireAuth(async () => {
          await revealPassword(pwd)
        })
        return
      }
      await revealPassword(pwd)
    }
  }

  const revealPassword = async (pwd: Password) => {
    if (!masterPassword) return
    setLoadingId(pwd.id)
    try {
      const decrypted = await getDecryptedPassword(pwd.password, masterPassword)
      setVisiblePasswords((prev) => {
        const next = new Map(prev)
        next.set(pwd.id, decrypted)
        return next
      })
    } catch (e) {
      console.error("Failed to decrypt password", e)
    }
    setLoadingId(null)
  }

  const copyPassword = async (pwd: Password) => {
    if (!masterPassword) return

    // For hard protection level, require re-authentication
    if (pwd.protectionLevel === "hard" && !visiblePasswords.has(pwd.id)) {
      onRequireAuth(async () => {
        await performCopy(pwd)
      })
      return
    }

    await performCopy(pwd)
  }

  const performCopy = async (pwd: Password) => {
    if (!masterPassword) return

    try {
      let passwordToCopy = visiblePasswords.get(pwd.id)
      if (!passwordToCopy) {
        passwordToCopy = await getDecryptedPassword(pwd.password, masterPassword)
      }
      await navigator.clipboard.writeText(passwordToCopy)
      setCopiedId(pwd.id)
      setTimeout(() => setCopiedId(null), 2000)
    } catch (e) {
      console.error("Failed to copy password", e)
    }
  }

  if (passwords.length === 0) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="p-8 text-center">
          <Key className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-medium text-foreground mb-1">No passwords yet</h3>
          <p className="text-sm text-muted-foreground">Add your first password to get started</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      {passwords.map((pwd) => {
        const isVisible = visiblePasswords.has(pwd.id)
        const isCopied = copiedId === pwd.id
        const isDeleting = confirmDelete === pwd.id
        const isLoading = loadingId === pwd.id

        return (
          <Card key={pwd.id} className="bg-card border-border overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-medium text-foreground truncate">{pwd.name}</h3>
                    <ProtectionBadge level={pwd.protectionLevel} size="sm" showLabel={false} />
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{pwd.username}</p>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex-1 font-mono text-sm bg-secondary rounded px-2 py-1 overflow-hidden">
                      {isLoading ? (
                        <span className="text-muted-foreground">Decrypting...</span>
                      ) : isVisible ? (
                        <span className="text-foreground break-all">{visiblePasswords.get(pwd.id)}</span>
                      ) : (
                        <span className="text-muted-foreground">••••••••••••</span>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Updated {formatDistanceToNow(new Date(pwd.updatedAt), { addSuffix: true })}
                  </p>
                </div>
                <div className="flex flex-col gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground"
                    onClick={() => toggleVisibility(pwd)}
                    disabled={isLoading}
                  >
                    {isVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground"
                    onClick={() => onEdit(pwd)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Action bar */}
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground text-xs h-7"
                  onClick={() => copyPassword(pwd)}
                >
                  {isCopied ? (
                    <>
                      <Check className="h-3 w-3 mr-1 text-primary" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" /> Copy
                    </>
                  )}
                </Button>

                {pwd.protectionLevel === "hard" && (
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Lock className="h-3 w-3" />
                    <span>Re-auth required</span>
                  </div>
                )}

                {isDeleting ? (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-destructive">Delete?</span>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() => {
                        onDelete(pwd.id)
                        setConfirmDelete(null)
                      }}
                    >
                      Yes
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setConfirmDelete(null)}>
                      No
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive text-xs h-7"
                    onClick={() => setConfirmDelete(pwd.id)}
                  >
                    <Trash2 className="h-3 w-3 mr-1" /> Delete
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

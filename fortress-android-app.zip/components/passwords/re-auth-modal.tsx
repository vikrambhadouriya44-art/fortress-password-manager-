"use client"

import type React from "react"

import { useState } from "react"
import { verifyMasterPassword } from "@/lib/storage"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Lock, AlertCircle, X, ShieldAlert } from "lucide-react"

interface ReAuthModalProps {
  isOpen: boolean
  onSuccess: () => void
  onCancel: () => void
}

export function ReAuthModal({ isOpen, onSuccess, onCancel }: ReAuthModalProps) {
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    const isValid = await verifyMasterPassword(password)
    if (isValid) {
      setPassword("")
      onSuccess()
    } else {
      setError("Incorrect password")
    }
    setIsLoading(false)
  }

  const handleClose = () => {
    setPassword("")
    setError("")
    onCancel()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
      <Card className="w-full max-w-sm border-border bg-card">
        <CardHeader className="text-center pb-4 relative">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            className="absolute right-4 top-4 text-muted-foreground"
          >
            <X className="h-4 w-4" />
          </Button>
          <div className="mx-auto w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-2">
            <ShieldAlert className="h-6 w-6 text-primary" />
          </div>
          <CardTitle className="text-lg">Re-authentication Required</CardTitle>
          <CardDescription>This item has hard protection. Enter your master password to continue.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="reauth-password">Master Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="reauth-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="pl-10 bg-secondary border-border"
                  autoFocus
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-destructive text-sm">
                <AlertCircle className="h-4 w-4" />
                {error}
              </div>
            )}

            <div className="flex gap-3">
              <Button type="button" variant="outline" className="flex-1 bg-transparent" onClick={handleClose}>
                Cancel
              </Button>
              <Button type="submit" className="flex-1" disabled={isLoading || !password}>
                {isLoading ? "Verifying..." : "Confirm"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

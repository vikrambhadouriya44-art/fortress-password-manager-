"use client"

import { Shield, ShieldCheck, ShieldAlert } from "lucide-react"
import { cn } from "@/lib/utils"

interface ProtectionBadgeProps {
  level: "easy" | "moderate" | "hard"
  showLabel?: boolean
  size?: "sm" | "md" | "lg"
}

export function ProtectionBadge({ level, showLabel = true, size = "md" }: ProtectionBadgeProps) {
  const config = {
    easy: {
      icon: Shield,
      label: "Easy",
      className: "bg-chart-3/20 text-chart-3 border-chart-3/30",
    },
    moderate: {
      icon: ShieldCheck,
      label: "Moderate",
      className: "bg-chart-2/20 text-chart-2 border-chart-2/30",
    },
    hard: {
      icon: ShieldAlert,
      label: "Hard",
      className: "bg-primary/20 text-primary border-primary/30",
    },
  }

  const { icon: Icon, label, className } = config[level]

  const sizeClasses = {
    sm: "text-xs px-1.5 py-0.5 gap-1",
    md: "text-sm px-2 py-1 gap-1.5",
    lg: "text-base px-3 py-1.5 gap-2",
  }

  const iconSizes = {
    sm: 12,
    md: 14,
    lg: 16,
  }

  return (
    <span className={cn("inline-flex items-center rounded-md border font-medium", className, sizeClasses[size])}>
      <Icon size={iconSizes[size]} />
      {showLabel && label}
    </span>
  )
}

"use client"

import { Shield } from "lucide-react"

interface FortressIconProps {
  size?: number
  className?: string
}

export function FortressIcon({ size = 48, className = "" }: FortressIconProps) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <div className="absolute inset-0 bg-primary/20 rounded-xl blur-xl" />
      <div className="relative bg-card border border-border rounded-xl p-3">
        <Shield className="text-primary" size={size} strokeWidth={1.5} />
      </div>
    </div>
  )
}

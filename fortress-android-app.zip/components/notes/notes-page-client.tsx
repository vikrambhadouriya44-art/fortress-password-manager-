"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { addNote, updateNote, deleteNote, type Note } from "@/lib/storage"
import { NoteList } from "@/components/notes/note-list"
import { NoteEditor } from "@/components/notes/note-editor"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Plus, FileText, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export function NotesPageClient() {
  const router = useRouter()
  const { isAuthenticated, masterPassword, vault, refreshVault } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [editingNote, setEditingNote] = useState<Note | null>(null)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/")
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated || !masterPassword) {
    return null
  }

  const notes = vault?.notes || []
  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleSave = async (noteData: { title: string; content: string; isLocked: boolean }) => {
    if (editingNote) {
      await updateNote(editingNote.id, noteData, masterPassword)
    } else {
      await addNote(noteData, masterPassword)
    }
    await refreshVault()
    setIsEditing(false)
    setEditingNote(null)
  }

  const handleEdit = (note: Note) => {
    setEditingNote(note)
    setIsEditing(true)
  }

  const handleDelete = async (id: string) => {
    await deleteNote(id, masterPassword)
    await refreshVault()
  }

  const handleToggleLock = async (id: string, locked: boolean) => {
    await updateNote(id, { isLocked: locked }, masterPassword)
    await refreshVault()
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center gap-3 px-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="text-muted-foreground">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-chart-2" />
            <span className="font-semibold text-foreground">Secure Notes</span>
          </div>
          <div className="ml-auto">
            {!isEditing && (
              <Button
                size="sm"
                onClick={() => {
                  setEditingNote(null)
                  setIsEditing(true)
                }}
              >
                <Plus className="h-4 w-4 mr-1" />
                New
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-6 space-y-4">
        {isEditing ? (
          <NoteEditor
            note={editingNote}
            onSave={handleSave}
            onCancel={() => {
              setIsEditing(false)
              setEditingNote(null)
            }}
          />
        ) : (
          <>
            {/* Search */}
            {notes.length > 0 && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search notes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-card border-border"
                />
              </div>
            )}

            {/* Notes List */}
            <NoteList
              notes={filteredNotes}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onToggleLock={handleToggleLock}
            />
          </>
        )}
      </main>
    </div>
  )
}

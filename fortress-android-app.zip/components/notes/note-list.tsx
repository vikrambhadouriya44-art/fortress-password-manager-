"use client"

import { useState } from "react"
import type { Note } from "@/lib/storage"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Lock, Unlock, Trash2, Edit, Eye, EyeOff } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

interface NoteListProps {
  notes: Note[]
  onEdit: (note: Note) => void
  onDelete: (id: string) => void
  onToggleLock: (id: string, locked: boolean) => void
}

export function NoteList({ notes, onEdit, onDelete, onToggleLock }: NoteListProps) {
  const [visibleNotes, setVisibleNotes] = useState<Set<string>>(new Set())
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null)

  const toggleVisibility = (id: string) => {
    setVisibleNotes((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  if (notes.length === 0) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="p-8 text-center">
          <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-medium text-foreground mb-1">No notes yet</h3>
          <p className="text-sm text-muted-foreground">Create your first secure note to get started</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      {notes.map((note) => {
        const isVisible = visibleNotes.has(note.id)
        const isDeleting = confirmDelete === note.id

        return (
          <Card key={note.id} className="bg-card border-border overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {note.isLocked ? (
                      <Lock className="h-4 w-4 text-primary flex-shrink-0" />
                    ) : (
                      <Unlock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    )}
                    <h3 className="font-medium text-foreground truncate">{note.title}</h3>
                  </div>
                  <p
                    className={`text-sm text-muted-foreground line-clamp-2 ${!isVisible && note.isLocked ? "blur-sm select-none" : ""}`}
                  >
                    {note.content}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Updated {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
                  </p>
                </div>
                <div className="flex flex-col gap-1">
                  {note.isLocked && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground"
                      onClick={() => toggleVisibility(note.id)}
                    >
                      {isVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground"
                    onClick={() => onEdit(note)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Action bar */}
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground text-xs h-7"
                  onClick={() => onToggleLock(note.id, !note.isLocked)}
                >
                  {note.isLocked ? (
                    <>
                      <Unlock className="h-3 w-3 mr-1" /> Unlock
                    </>
                  ) : (
                    <>
                      <Lock className="h-3 w-3 mr-1" /> Lock
                    </>
                  )}
                </Button>
                {isDeleting ? (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-destructive">Delete?</span>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() => {
                        onDelete(note.id)
                        setConfirmDelete(null)
                      }}
                    >
                      Yes
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setConfirmDelete(null)}>
                      No
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive text-xs h-7"
                    onClick={() => setConfirmDelete(note.id)}
                  >
                    <Trash2 className="h-3 w-3 mr-1" /> Delete
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

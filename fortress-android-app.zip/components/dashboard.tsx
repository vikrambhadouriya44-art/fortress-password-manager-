"use client"

import { useAuth } from "@/contexts/auth-context"
import { FortressIcon } from "@/components/fortress-icon"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Key, Shield, LogOut, Settings, ChevronRight, Lock, ShieldCheck } from "lucide-react"
import Link from "next/link"

export function Dashboard() {
  const { vault, logout } = useAuth()

  const notesCount = vault?.notes?.length || 0
  const passwordsCount = vault?.passwords?.length || 0
  const totalItems = notesCount + passwordsCount

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <FortressIcon size={20} />
            <span className="font-semibold text-foreground">FORTRESS</span>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/settings">
              <Button variant="ghost" size="icon" className="text-muted-foreground">
                <Settings className="h-5 w-5" />
                <span className="sr-only">Settings</span>
              </Button>
            </Link>
            <Button variant="ghost" size="icon" onClick={logout} className="text-muted-foreground">
              <LogOut className="h-5 w-5" />
              <span className="sr-only">Logout</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-6 space-y-6">
        {/* Security Status */}
        <Card className="bg-card border-border overflow-hidden">
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h2 className="text-lg font-semibold text-foreground">Vault Status</h2>
                <p className="text-sm text-muted-foreground">Your data is protected</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
                <ShieldCheck className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <span className="text-muted-foreground">AES-256 Encryption</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <span className="text-muted-foreground">Offline Storage</span>
              </div>
            </div>
          </div>
          <div className="border-t border-border bg-secondary/30 px-6 py-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Total protected items</span>
              <span className="font-medium text-foreground">{totalItems}</span>
            </div>
          </div>
        </Card>

        {/* Quick Access */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted-foreground px-1">Quick Access</h3>
          <div className="grid gap-3">
            <Link href="/notes">
              <Card className="bg-card border-border hover:bg-secondary/50 transition-colors cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-lg bg-chart-2/20 flex items-center justify-center">
                        <FileText className="h-5 w-5 text-chart-2" />
                      </div>
                      <div>
                        <h3 className="font-medium text-foreground">Secure Notes</h3>
                        <p className="text-sm text-muted-foreground">{notesCount} notes stored</p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/passwords">
              <Card className="bg-card border-border hover:bg-secondary/50 transition-colors cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                        <Key className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium text-foreground">Password Manager</h3>
                        <p className="text-sm text-muted-foreground">{passwordsCount} passwords saved</p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>

        {/* Security Tips */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              Security Tips
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <Lock className="h-4 w-4 text-muted-foreground mt-0.5" />
              <p className="text-sm text-muted-foreground">Use strong, unique passwords for each account</p>
            </div>
            <div className="flex items-start gap-3">
              <Shield className="h-4 w-4 text-muted-foreground mt-0.5" />
              <p className="text-sm text-muted-foreground">
                Enable &quot;Hard&quot; protection for sensitive credentials
              </p>
            </div>
            <div className="flex items-start gap-3">
              <Key className="h-4 w-4 text-muted-foreground mt-0.5" />
              <p className="text-sm text-muted-foreground">Never share your master password with anyone</p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

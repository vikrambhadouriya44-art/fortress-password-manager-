import { Suspense } from "react"
import { PasswordsPageClient } from "@/components/passwords/passwords-page-client"

export default function PasswordsPage() {
  return (
    <Suspense fallback={null}>
      <PasswordsPageClient />
    </Suspense>
  )
}

"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { FortressIcon } from "@/components/fortress-icon"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Shield, Lock, Key, Database, WifiOff, ShieldCheck } from "lucide-react"

export default function AboutPage() {
  const router = useRouter()
  const { isAuthenticated } = useAuth()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/")
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center gap-3 px-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => router.push("/settings")}
            className="text-muted-foreground"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <span className="font-semibold text-foreground">About</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-6 space-y-6">
        {/* Logo and Title */}
        <div className="text-center space-y-4 py-4">
          <FortressIcon size={48} className="mx-auto" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">FORTRESS</h1>
            <p className="text-muted-foreground">Version 1.0.0</p>
          </div>
          <p className="text-sm text-muted-foreground max-w-xs mx-auto">
            A secure personal vault for storing notes and passwords with military-grade encryption
          </p>
        </div>

        {/* Security Features */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              Security Features
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Lock className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-foreground text-sm">AES-256-GCM Encryption</h3>
                <p className="text-xs text-muted-foreground">
                  All data is encrypted using the Advanced Encryption Standard with 256-bit keys and Galois/Counter Mode
                  for authenticated encryption.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Key className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-foreground text-sm">PBKDF2 Key Derivation</h3>
                <p className="text-xs text-muted-foreground">
                  Your master password is strengthened using PBKDF2 with SHA-256 and up to 200,000 iterations, making
                  brute-force attacks computationally expensive.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Database className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-foreground text-sm">Local Storage Only</h3>
                <p className="text-xs text-muted-foreground">
                  Your encrypted data never leaves your device. No cloud sync, no servers - complete privacy and
                  control.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                <WifiOff className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-foreground text-sm">Offline First</h3>
                <p className="text-xs text-muted-foreground">
                  FORTRESS works entirely offline. Install it as a PWA on your device and access your vault anytime,
                  anywhere.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Protection Levels */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-primary" />
              Protection Levels
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 bg-chart-3/10 rounded-lg border border-chart-3/20">
              <h3 className="font-medium text-chart-3 text-sm flex items-center gap-2">
                <Shield className="h-4 w-4" /> Easy
              </h3>
              <p className="text-xs text-muted-foreground mt-1">
                50,000 PBKDF2 iterations. Suitable for less sensitive data that needs quick access.
              </p>
            </div>

            <div className="p-3 bg-chart-2/10 rounded-lg border border-chart-2/20">
              <h3 className="font-medium text-chart-2 text-sm flex items-center gap-2">
                <ShieldCheck className="h-4 w-4" /> Moderate
              </h3>
              <p className="text-xs text-muted-foreground mt-1">
                100,000 PBKDF2 iterations. Recommended for most passwords and sensitive notes.
              </p>
            </div>

            <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
              <h3 className="font-medium text-primary text-sm flex items-center gap-2">
                <Lock className="h-4 w-4" /> Hard
              </h3>
              <p className="text-xs text-muted-foreground mt-1">
                200,000 PBKDF2 iterations + re-authentication required. Maximum security for your most critical
                credentials.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base">How Encryption Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <p>
              <span className="text-foreground font-medium">1. Key Derivation:</span> When you enter your master
              password, FORTRESS uses PBKDF2 to derive a strong cryptographic key. This process is intentionally slow to
              resist brute-force attacks.
            </p>
            <p>
              <span className="text-foreground font-medium">2. Encryption:</span> Your data is encrypted using
              AES-256-GCM, which provides both confidentiality and integrity. Each piece of data gets a unique
              initialization vector (IV).
            </p>
            <p>
              <span className="text-foreground font-medium">3. Storage:</span> The encrypted data, along with the salt
              and IV, is stored locally on your device. Without your master password, the data is unreadable.
            </p>
            <p>
              <span className="text-foreground font-medium">4. Zero Knowledge:</span> Your master password is never
              stored. Only a secure hash is kept to verify your identity. If you forget your password, your data cannot
              be recovered.
            </p>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center py-4 space-y-2">
          <p className="text-xs text-muted-foreground">Built with security in mind</p>
          <p className="text-xs text-muted-foreground">Uses Web Crypto API for all cryptographic operations</p>
        </div>
      </main>
    </div>
  )
}
